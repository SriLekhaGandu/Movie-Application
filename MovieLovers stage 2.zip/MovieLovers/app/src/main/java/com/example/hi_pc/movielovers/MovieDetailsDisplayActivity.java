package com.example.hi_pc.movielovers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;


public class MovieDetailsDisplayActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
    final int OPERATION_SEARCH_LOADER = 10;
    @BindView(R.id.votes)
    TextView tv_vote;
    @BindView(R.id.tr)
    TextView tr;
    @BindView(R.id.rating)
    TextView tv_rating;
    @BindView(R.id.release_date)
    TextView tv_date;
    @BindView(R.id.language)
    TextView tv_language;
    @BindView(R.id.movie_poster)
    ImageView iv_foreground;
    @BindView(R.id.background_movie)
    ImageView iv_background;
    @BindView(R.id.overview)
    TextView tv_overview;
    @BindView(R.id.rv)
    TextView rv;
    @BindView(R.id.rating_bar)
    RatingBar ratingBar;
    TextView tv_trailer, tv_review;
    RecyclerView trailer_view, review_view;
    TrailerAdapter trailerAdapter;
    ReviewAdapter reviewAdapter;
    SQLiteDatabase sqLiteDatabase;
    ArrayList<JSONTrailer> jsonTrailerList;
    ArrayList<JSONReview> jsonReviewList;
    int id;
    String response;
    String reviewString;
    String trailerString;
    CheckBox chfav;
    private int flag = 0;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details_display);
        jsonTrailerList = new ArrayList<JSONTrailer>();
        jsonReviewList = new ArrayList<JSONReview>();
        final FavouriteDBHelper dbHelper = new FavouriteDBHelper(this);
        sqLiteDatabase = dbHelper.getWritableDatabase();
        Bundle bundle = getIntent().getExtras();
        ButterKnife.bind(this);
        Uri uri = FavouriteContract.CONTENT_URI;
        tv_trailer = (TextView) findViewById(R.id.recycler_trailer_view);
        trailer_view = (RecyclerView) findViewById(R.id.trailer_recycle_view);
        tv_review = (TextView) findViewById(R.id.recycler_trailer_view);
        review_view = (RecyclerView) findViewById(R.id.review_recycle_view);
        final String bposter = bundle.getString(String.valueOf(R.string.BACKDROP_POSTER));
        id = bundle.getInt(String.valueOf(R.string.ID));
        trailerString = MoviesDisplay.LINK + "" + id + "/videos?api_key=e423927ea7fb83ade7f800633300179c";
        reviewString = MoviesDisplay.LINK + "" + id + "/reviews?api_key=e423927ea7fb83ade7f800633300179c";
        final String poster = bundle.getString(String.valueOf(R.string.POSTER_PATH));
        final String title = bundle.getString(String.valueOf(R.string.ORIGINAL_TITLE));
        final double rating = bundle.getDouble(String.valueOf(R.string.VOTE_AVERAGE));
        final long votes = bundle.getLong(String.valueOf(R.string.VOTE_COUNT));
        final String release_date = bundle.getString(String.valueOf(R.string.RELEASE_DATE));
        final String language = bundle.getString(String.valueOf(R.string.ORIGINAL_LANGUAGE));
        final String overview = bundle.getString(String.valueOf(R.string.OVERVIEW));
        if (checkOnline()) {
            Picasso.with(getApplicationContext()).load(bposter).into(iv_background);
            Picasso.with(getApplicationContext()).load(poster).into(iv_foreground);
        } else {
            Picasso.with(getApplicationContext()).load(bposter).placeholder(R.drawable.image).into(iv_background);
            Picasso.with(getApplicationContext()).load(poster).placeholder(R.drawable.image).into(iv_foreground);
        }
        setTitle(title);
        tv_rating.setText("Rating: " + rating);
        tv_vote.setText("Votes: " + votes);
        tv_date.setText("Date:" + release_date);
        tv_language.setText("langugae: " + language);
        tv_overview.setText(overview);
        ratingBar.setBackgroundColor(Color.WHITE);
        chfav = (CheckBox) findViewById(R.id.action_favorite);
        Uri myUri = uri.buildUpon().appendPath(String.valueOf(id)).build();
        Cursor cursor = getContentResolver().query(myUri, null, null, null, null);
        if (cursor.getCount() > 0) {
            chfav.setButtonDrawable(R.drawable.checked);
            flag = 1;
        }
        cursor.close();
        chfav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chfav.isChecked() && flag != 1) {
                    chfav.setButtonDrawable(R.drawable.checked);
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_BACKDROP_PATH, bposter);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_POSTER_PATH, poster);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_TITLE, title);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_FAVOURITE, true);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_RATING, rating);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_VOTES, votes);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_RELEASE_DATE, release_date);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_OVERVIEW, overview);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_ID, id);
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_LANGUAGE, language);
                    Uri uri = getContentResolver().insert(FavouriteContract.CONTENT_URI, contentValues);
                    if (uri != null) {
                        Toast.makeText(getApplicationContext(), uri.toString(), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    chfav.setButtonDrawable(R.drawable.unchecked);
                    flag = 0;
                    String stringid = Integer.toString(id);
                    Uri uri = FavouriteContract.CONTENT_URI;
                    int res = getContentResolver().delete(uri, stringid, null);
                    if (res < 0) {
                        Toast.makeText(getApplicationContext(), "Error while deleting", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        ratingBar.setMax(10);
        ratingBar.setNumStars(10);
        ratingBar.setRating((float) rating);
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        final NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null) {
            getSupportLoaderManager().restartLoader(OPERATION_SEARCH_LOADER, null, this);
        } else {
            tr.setVisibility(View.GONE);
            rv.setVisibility(View.GONE);
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.NoInternet), Toast.LENGTH_SHORT).show();
        }
    }

    public boolean checkOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null)
            return true;
        else
            return false;
    }

    @Override
    public Loader<String> onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader<String>(this) {
            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
            }

            @Override
            public String loadInBackground() {
                URL trailerUrl = null;
                GetMovieDetailsURL connect = new GetMovieDetailsURL();
                try {
                    trailerUrl = connect.buildMovieUrl(trailerString);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                String trailerResponse = null;
                int i = 0;
                trailerResponse = connect.getMovieDetailsResponse(trailerUrl);
                try {
                    JSONObject movieObject = new JSONObject(trailerResponse);
                    JSONArray trailerArray = movieObject.getJSONArray(getResources().getString(R.string.Results));
                    while (i < trailerArray.length()) {
                        JSONObject trailer = trailerArray.getJSONObject(i);
                        String trailer_id = trailer.optString(getResources().getString(R.string.ID));
                        String trailer_langugae = trailer.optString(getResources().getString(R.string.TRAILER_LANGUAGE));
                        String trailer_country = trailer.optString(getResources().getString(R.string.TRAILER_COUNTRY));
                        String trailer_key = trailer.optString(getResources().getString(R.string.TRAILER_KEY));
                        String trailer_name = trailer.optString(getResources().getString(R.string.TRAILER_NAME));
                        String trailer_site = trailer.optString(getResources().getString(R.string.TRAILER_SITE));
                        long trailer_size = trailer.optLong(getResources().getString(R.string.TRAILER_SIZE));
                        String trailer_type = trailer.optString(getResources().getString(R.string.TRAILER_TYPE));
                        String trailer_url = getResources().getString(R.string.TRAILER_URL) + trailer_key;
                        JSONTrailer jsonTrailer = new JSONTrailer(trailer_url, trailer_id, trailer_langugae, trailer_country, trailer_key, trailer_name, trailer_site, trailer_size, trailer_type);
                        jsonTrailerList.add(jsonTrailer);
                        response = jsonTrailer.getTrailer_url();
                        i++;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                URL reviewUrl = null;
                GetMovieDetailsURL connection = new GetMovieDetailsURL();
                try {
                    reviewUrl = connection.buildMovieUrl(reviewString);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                String reviewResponse = null;
                i = 0;
                reviewResponse = connection.getMovieDetailsResponse(reviewUrl);
                try {
                    JSONObject movieObject = new JSONObject(reviewResponse);
                    JSONArray reviewArray = movieObject.getJSONArray("results");
                    while (i < reviewArray.length()) {
                        JSONObject review = reviewArray.getJSONObject(i);
                        String review_id = review.getString(getResources().getString(R.string.ID));
                        String review_content = review.getString(getResources().getString(R.string.REVIEW_CONTENT));
                        String review_author = review.getString(getResources().getString(R.string.REVIEW_AUTHOR));
                        String review_url = review.getString(getResources().getString(R.string.REVIEW_URL));
                        JSONReview jsonReview = new JSONReview(review_id, review_content, review_author, review_url);
                        jsonReviewList.add(jsonReview);
                        i++;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return response;
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String data) {
        if (jsonTrailerList.size() <= 0)
            tr.setVisibility(View.GONE);
        trailerAdapter = new TrailerAdapter(MovieDetailsDisplayActivity.this, jsonTrailerList);
        trailer_view.setLayoutManager(new LinearLayoutManager(this));
        trailer_view.setAdapter(trailerAdapter);
        if (jsonReviewList.size() <= 0)
            rv.setVisibility(View.GONE);
        reviewAdapter = new ReviewAdapter(MovieDetailsDisplayActivity.this, jsonReviewList);
        review_view.setLayoutManager(new LinearLayoutManager(this));
        review_view.setAdapter(reviewAdapter);
    }

    @Override
    public void onLoaderReset(Loader<String> loader) {
        loader.forceLoad();
    }
}