package com.example.hi_pc.movielovers;

public class JSONReview {
    String review_id;
    String review_content;
    String review_author;
    String review_url;

    public JSONReview(String review_id, String review_content, String review_author, String review_url) {
        this.review_id = review_id;
        this.review_content = review_content;
        this.review_author = review_author;
        this.review_url = review_url;
    }

    public String getReview_id() {
        return review_id;
    }

    public String getReview_content() {
        return review_content;
    }

    public String getReview_author() {
        return review_author;
    }

    public String getReview_url() {
        return review_url;
    }
}
