package com.example.hi_pc.movielovers;

public class JSONData {
    String movie_background_poster;
    String movie_poster;
    String movie_title;
    String movie_release_date;
    String movie_language;
    String movie_overview;
    String title;
    double movie_vote_average;
    long movie_votes;
    int movie_id;

    public JSONData(int movie_id, String movie_background_poster, String movie_poster, String movie_title, double movie_vote_average, long movie_votes, String movie_release_date, String movie_language, String movie_overview) {
        this.movie_id = movie_id;
        this.movie_background_poster = movie_background_poster;
        this.movie_poster = movie_poster;
        this.movie_title = movie_title;
        this.movie_release_date = movie_release_date;
        this.movie_language = movie_language;
        this.movie_overview = movie_overview;
        this.movie_vote_average = movie_vote_average;
        this.movie_votes = movie_votes;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getMovie_id() {
        return movie_id;
    }

    public String getMovie_background_poster() {
        return movie_background_poster;
    }

    public String getMovie_poster() {
        return movie_poster;
    }

    public String getMovie_title() {
        return movie_title;
    }

    public String getMovie_release_date() {
        return movie_release_date;
    }

    public String getMovie_language() {
        return movie_language;
    }

    public String getMovie_overview() {
        return movie_overview;
    }

    public double getMovie_vote_average() {
        return movie_vote_average;
    }

    public long getMovie_votes() {
        return movie_votes;
    }
}
